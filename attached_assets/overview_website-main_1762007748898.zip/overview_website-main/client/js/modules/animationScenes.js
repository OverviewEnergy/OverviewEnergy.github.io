export const ANIMATION_SCENES = [
  {
    build: { start: 0, end: 119 },
    loop: { start: 120, end: 179 }
  },
  {
    build: { start: 180, end: 299 },
    loop: { start: 300, end: 359 }
  },
  {
    build: { start: 360, end: 419 },
    loop: { start: 420, end: 479 }
  },
  {
    build: { start: 480, end: 599 },
    loop: { start: 600, end: 779 }
  },
  {
    build: { start: 780, end: 899 },
    loop: { start: 900, end: 959 }
  },
  {
    build: { start: 960, end: 1079 },
    loop: { start: 1080, end: 1139 }
  },
  {
    build: { start: 1140, end: 1229 },
    loop: { start: 1230, end: 1419 }
  }
];